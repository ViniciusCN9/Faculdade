def criar_bmp(nomeArquivo):
    with open(nomeArquivo, 'wb') as arquivo:
        # Cabeçalho do arquivo BMP
        arquivo.write(b'BM')  # Tipo: Indica que é um arquivo BMP. "BM" em ASCII.
        
        # Tamanho do arquivo: 14 (cabeçalho BMP) + 40 (cabeçalho DIB) + 3*20*20 (imagem)
        tamanhoArquivo = 14 + 40 + 3 * 20 * 20
        arquivo.write(int(tamanhoArquivo).to_bytes(4, 'little'))  # Convertendo tamanho do arquivo para bytes no formato little-endian
        
        arquivo.write(int(0).to_bytes(4, 'little'))  # Reservado: Valores padrão que são reservados e devem ser 0.
        
        # Deslocamento dos dados da imagem: Indica onde começam os dados da imagem no arquivo. 14 + 40 = 54.
        arquivo.write(int(54).to_bytes(4, 'little')) 
        
        # Cabeçalho DIB (BITMAPINFOHEADER, que tem tamanho fixo de 40 bytes)
        arquivo.write(int(40).to_bytes(4, 'little')) # Tamanho do cabeçalho DIB
        
        arquivo.write(int(20).to_bytes(4, 'little'))  # Largura da imagem: 20 pixels
        arquivo.write(int(20).to_bytes(4, 'little'))  # Altura da imagem: 20 pixels
        
        arquivo.write(int(1).to_bytes(2, 'little'))  # Planos de cores: Valor padrão é 1.
        
        arquivo.write(int(24).to_bytes(2, 'little')) # Bits por pixel: Usando 24 bits por pixel, ou seja, formato RGB.
        
        arquivo.write(int(0).to_bytes(4, 'little'))  # Método de compressão: Sem compressão.
        
        # Tamanho da imagem (em bytes): Para uma imagem RGB, são 3 bytes por pixel. Então 3*20*20 = 1200 bytes.
        arquivo.write(int(3*20*20).to_bytes(4, 'little'))
        
        arquivo.write(int(0).to_bytes(4, 'little'))  # Resolução horizontal (pixel/m): 0 por padrão.
        arquivo.write(int(0).to_bytes(4, 'little'))  # Resolução vertical (pixel/m): 0 por padrão.
        arquivo.write(int(0).to_bytes(4, 'little'))  # Cores na paleta: 0 indica que não estamos usando uma paleta.
        arquivo.write(int(0).to_bytes(4, 'little'))  # Cores importantes: 0 indica todas as cores.
        
        # Dados da imagem: Como cada pixel é amarelo, os valores RGB são (255, 255, 0).
        for _ in range(20*20):  # Como temos 20x20 pixels, repetimos 400 vezes.
            arquivo.write(b'\x00\xff\xff')  # RGB para amarelo.

criar_bmp('amarelo.bmp')