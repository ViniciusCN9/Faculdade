### Informações

Nome: Vinicius Fernandes Escobedo
Curso: Engenharia da computação
Termo: 5°

### Bibliotecas

npm install prompt-sync

