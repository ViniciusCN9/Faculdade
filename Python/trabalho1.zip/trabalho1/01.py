aluno = {
    "nome": "vinicius",
    "idade": 24,
    "curso": "engenharia da computação"
}

print(aluno["nome"])
print(aluno["idade"])
print(aluno["curso"])
