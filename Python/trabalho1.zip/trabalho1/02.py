aluno = {
    "nome": "vinicius",
    "idade": 24,
    "curso": "engenharia da computação"
}

aluno["semestre"] = 2
del aluno["idade"]
print(aluno)
