import os

conteudo = os.listdir()

for item in conteudo:
    print(item)
