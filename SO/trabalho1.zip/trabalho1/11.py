with open("meuarquivo.txt", "r") as file:
    conteudo = file.read()
    print(conteudo)
