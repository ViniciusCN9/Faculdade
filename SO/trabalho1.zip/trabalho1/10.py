with open("meuarquivo.txt", "w") as file:
    file.write("Este é um arquivo de exemplo.")
